package net.javaguide.sms.controller;

import java.util.Optional;

import javax.management.Query;

import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.support.EntityManagerBeanDefinitionRegistrarPostProcessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import net.javaguide.sms.entity.Student;
import net.javaguide.sms.service.StudentService;

@Controller
public class StudentController {

	private StudentService studentService;

	public StudentController(StudentService studentService) {
		this.studentService = studentService;
	}
	// handler method to handle list student and return mode and view 
	@GetMapping("/students")
	public String listStudent(Model model) {
		model.addAttribute("students",studentService.getAllStudents());
		return "students";
	}
	@GetMapping("/students/new")
	public String createStudentForm(Model model) {
		// create student object to hold student form data 
		Student student = new Student();
		model.addAttribute("student",student);
		return"creat_student";
	}
	
	@PostMapping("/students")
	public String saveStudent(@ModelAttribute("student")Student student ) {
		studentService.saveStudent(student);
		return"redirect:/students";
	}
	 // update pages  
	@GetMapping("/students/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("student",studentService.getStudentById(id));
		return "edit_student";
	}
	
	@PostMapping("/students/{id}")
	public String updateStudent(@PathVariable Long id, @ModelAttribute("student")  Student student , Model model) {
		// get student from DB by id 
		
		Student existingStudent = studentService.getStudentById(id);
		existingStudent.setId(id);
		existingStudent.setFirsteName(student.getFirsteName());
		existingStudent.setLasteNAme(student.getLasteNAme());
		existingStudent.setEmail(student.getEmail());
		// save update student object
		studentService.updateStudent(existingStudent);
		return "redirect:/students";
		
	}
	
	// handler methode to handle delete student requet
	@GetMapping("/students/{id}")
	public String deletStudent(@PathVariable Long id) {
		studentService.deleteStudentById(id);
		return "redirect:/students";
	}
	// delete all table 
	

}
