package net.javaguide.sms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // c'est pour dire a la spring  voila on va creer une BD
@Table(name="infoStudent") // nome du table
public class Student {
	
    @Id // pour le ID 
    @GeneratedValue(strategy = GenerationType.IDENTITY) // pour l incrementation auto 
	private Long id ;
    
    @Column(name = "first_name" , nullable = false) // remplir les colomnes 
	private String FirsteName;
    
    @Column(name = "Last_name")
	private String LasteNAme;
    
    @Column(name = "email")
	private String email;
    
	
	public Student() {
		
	}
	public Student( String firsteName, String lasteNAme, String email) {
		super();
		FirsteName = firsteName;
		LasteNAme = lasteNAme;
		this.email = email;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirsteName() {
		return FirsteName;
	}
	public void setFirsteName(String firsteName) {
		FirsteName = firsteName;
	}
	public String getLasteNAme() {
		return LasteNAme;
	}
	public void setLasteNAme(String lasteNAme) {
		LasteNAme = lasteNAme;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
}
