package net.javaguide.sms.service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import net.javaguide.sms.entity.Student;
import net.javaguide.sms.respository.StudentRepository;
import net.javaguide.sms.service.StudentService;
@Service

public class StudentServiceImpl implements StudentService {

	private StudentRepository studentRpositRepository ; 
	
	public StudentServiceImpl(StudentRepository studentRpositRepository) {
		super();
		this.studentRpositRepository = studentRpositRepository;
	}

	@Override
	public List<Student> getAllStudents() {
		return studentRpositRepository.findAll();
	}

	@Override
	public Student saveStudent(Student student) {
		
		return studentRpositRepository.save(student);
	}

	@Override
	public Student getStudentById(Long id) {
		return studentRpositRepository.findById(id).get();
	}

	@Override
	public Student updateStudent(Student student) {
		return studentRpositRepository.save(student);
	}

	@Override
	public void deleteStudentById(Long id) {
		studentRpositRepository.deleteById(id);
		
	}


	





}
