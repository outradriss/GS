package net.javaguide.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.javaguide.sms.entity.Student;
import net.javaguide.sms.respository.StudentRepository;

@SpringBootApplication
public class SystemGestionEtudiantApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SystemGestionEtudiantApplication.class, args);
	}
	
    @Autowired
    private StudentRepository studentRepository;
    
	@Override
	public void run(String... args) throws Exception {
	  
		/*
		 * Student student1 = new Student( "Driss","Outrah","outrahdriss9@gmail.com");
		 * studentRepository.save(student1)
		 */
	}

}

